package com.quiz.model;

public class Decrypt {
	public Teacher tdecrypt(Teacher t) {
		
		int i=0;
		char[] fname = new char[t.getFname().length()];
		char[] lname = new char[t.getLname().length()];		
		char[] tid = new char[t.getTid().length()];
		char[] did = new char[t.getDid().length()];
		char[] clg_id = new char[t.getClg_id().length()];
		char[] clg_name = new char[t.getClg_name().length()];
		char[] email = new char[t.getEmail().length()];
		char[] pass = new char[t.getPass().length()];

		//Encrypt First name
		for(i=0;i<t.getFname().length();i++) {
			fname[i] += t.getFname().charAt(i) - 1;
		}

		//Encrypt Last name
		for(i=0;i<t.getLname().length();i++) {
			lname[i] += t.getLname().charAt(i) - 1;
		}		

		//Encrypt Teacher ID
		for(i=0;i<t.getTid().length();i++) {
			tid[i] += t.getTid().charAt(i) - 1;
		}
		
		//Encrypt Department ID
		for(i=0;i<t.getDid().length();i++) {
			did[i] += t.getDid().charAt(i) - 1;
		}

		//Encrypt college ID
		for(i=0;i<t.getClg_id().length();i++) {
			clg_id[i] += t.getClg_id().charAt(i) - 1;
		}

		//Encrypt college Name		
		for(i=0;i<t.getClg_name().length();i++) {
			clg_name[i] += t.getClg_name().charAt(i) - 1;
		}

		//Encrypt Email
		for(i=0;i<t.getEmail().length();i++) {
			email[i] += t.getEmail().charAt(i) - 1;
		}

		//Encrypt Password
		for(i=0;i<t.getPass().length();i++) {
			pass[i] += t.getPass().charAt(i) - 1;
		}
		
		t = new Teacher(String.valueOf(fname), String.valueOf(lname),String.valueOf(tid),String.valueOf(did),String.valueOf(clg_id),String.valueOf(clg_name), String.valueOf(email),String.valueOf(pass));		
		
		return t;
	}
	public  String decryptstring(String s) {
		char[] ch = new char[s.length()];		
		for(int i=0;i<s.length();i++) {
			ch[i] += s.charAt(i) - 1;
		}
		return String.valueOf(ch);
	}
	
	public Student sdecrypt(Student s) {
		
		int i=0;
		char[] fname = new char[s.getFname().length()];
		char[] lname = new char[s.getLname().length()];		
		char[] tid = new char[s.getSid().length()];
		char[] did = new char[s.getDid().length()];
		char[] clg_id = new char[s.getClg_id().length()];
		char[] clg_name = new char[s.getClg_name().length()];
		char[] email = new char[s.getEmail().length()];
		char[] pass = new char[s.getPass().length()];

		//Encrypt First name
		for(i=0;i<s.getFname().length();i++) {
			fname[i] += s.getFname().charAt(i) - 1;
		}

		//Encrypt Last name
		for(i=0;i<s.getLname().length();i++) {
			lname[i] += s.getLname().charAt(i) - 1;
		}		

		//Encrypt Student ID
		for(i=0;i<s.getSid().length();i++) {
			tid[i] += s.getSid().charAt(i) - 1;
		}
		
		//Encrypt Department ID
		for(i=0;i<s.getDid().length();i++) {
			did[i] += s.getDid().charAt(i) - 1;
		}

		//Encrypt college ID
		for(i=0;i<s.getClg_id().length();i++) {
			clg_id[i] += s.getClg_id().charAt(i) - 1;
		}

		//Encrypt college Name		
		for(i=0;i<s.getClg_name().length();i++) {
			clg_name[i] += s.getClg_name().charAt(i) - 1;
		}

		//Encrypt Email
		for(i=0;i<s.getEmail().length();i++) {
			email[i] += s.getEmail().charAt(i) - 1;
		}
		
		//Encrypt Password
		for(i=0;i<s.getPass().length();i++) {
			pass[i] += s.getPass().charAt(i) - 1;
		}
		
		s = new Student(String.valueOf(fname), String.valueOf(lname),String.valueOf(tid),String.valueOf(did),String.valueOf(clg_id),String.valueOf(clg_name), String.valueOf(email),String.valueOf(pass));		
		
		return s;
	}
	public Subject subdecrypt(Subject s) {
		int i = 0;
		char[] tid = new char[s.getTid().length()];
		char[] did = new char[s.getDid().length()];
		char[] clg_id = new char[s.getClg_id().length()];
		char[] sub_id = new char[s.getSub_id().length()];
		char[] sub_name = new char[s.getSub_name().length()];

		//Encrypt Teacher ID
		for(i=0;i<s.getTid().length();i++) {
			tid[i] += s.getTid().charAt(i) - 1;
		}
		
		//Encrypt Teacher ID
		for(i=0;i<s.getDid().length();i++) {
			did[i] += s.getDid().charAt(i) - 1;
		}

		//Encrypt College ID
		for(i=0;i<s.getClg_id().length();i++) {
			clg_id[i] += s.getClg_id().charAt(i) - 1;
		}

		//Encrypt Subject ID
		for(i=0;i<s.getSub_id().length();i++) {
			sub_id[i] += s.getSub_id().charAt(i) - 1;
		}
		
		//Encrypt Subject Name
		for(i=0;i<s.getSub_name().length();i++) {
			sub_name[i] += s.getSub_name().charAt(i) - 1;
		}
		s = new Subject(String.valueOf(tid), String.valueOf(did),String.valueOf(clg_id),String.valueOf(sub_id), String.valueOf(sub_name));
		return s;
	}
	public Quiz quizdecrypt(Quiz q) {
		int i = 0;
		char[] tid = new char[q.getTid().length()];
		char[] did = new char[q.getDid().length()];
		char[] clg_id = new char[q.getClg_id().length()];
		char[] quiz_id = new char[q.getQuiz_id().length()];
		char[] quiz_name = new char[q.getQuiz_name().length()];
		char[] q_name = new char[q.getQname().length()];
		char[] op_1 = new char[q.getOp_1().length()];
		char[] op_2 = new char[q.getOp_2().length()];
		char[] op_3 = new char[q.getOp_3().length()];
		char[] op_4 = new char[q.getOp_4().length()];
		char[] Correct_ans = new char[q.getCorrect_ans().length()];
		
		int q_mark = q.getQ_marks() - 32;
		
		//Encrypt Teacher ID
		for(i=0;i<q.getTid().length();i++) {
			tid[i] += q.getTid().charAt(i) - 1;
		}
	
	
		//Encrypt Teacher ID
		for(i=0;i<q.getDid().length();i++) {
			did[i] += q.getDid().charAt(i) - 1;
		}
		
		//Encrypt College ID
		for(i=0;i<q.getClg_id().length();i++) {
			clg_id[i] += q.getClg_id().charAt(i) - 1;
		}

		//Encrypt Quiz ID
		for(i=0;i<q.getQuiz_id().length();i++) {
			quiz_id[i] += q.getQuiz_id().charAt(i) - 1;
		}
		for(i=0;i<q.getQuiz_name().length();i++) {
			quiz_name[i] += q.getQuiz_name().charAt(i) - 1;
		}
		for(i=0;i<q.getQname().length();i++) {
			q_name[i] += q.getQname().charAt(i) - 1;
		}
		
		for(i=0;i<q.getOp_1().length();i++) {
			op_1[i] += q.getOp_1().charAt(i) - 1;
		}
		for(i=0;i<q.getOp_2().length();i++) {
			op_2[i] += q.getOp_2().charAt(i) - 1;
		}
		for(i=0;i<q.getOp_3().length();i++) {
			op_3[i] += q.getOp_3().charAt(i) - 1;
		}
		for(i=0;i<q.getOp_4().length();i++) {
			op_4[i] += q.getOp_4().charAt(i) - 1;
		}
		for(i=0;i<q.getCorrect_ans().length();i++) {
			Correct_ans[i] += q.getCorrect_ans().charAt(i) - 1;
		}
		
		q = new Quiz(String.valueOf(tid), String.valueOf(did), String.valueOf(clg_id), String.valueOf(quiz_id),String.valueOf(quiz_name), String.valueOf(q_name), String.valueOf(op_1), String.valueOf(op_2), String.valueOf(op_3), String.valueOf(op_4), String.valueOf(Correct_ans), q_mark);		
		return q;
	}
}