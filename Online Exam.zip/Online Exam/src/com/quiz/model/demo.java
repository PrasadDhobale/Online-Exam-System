package com.quiz.model;

public class demo {

	public static void main(String[] args) {
		String s = "60";
		System.out.println(s+20);
		int i = Integer.parseInt(s);
		System.out.println(i+20);
	}

}
