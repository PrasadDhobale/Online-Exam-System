package com.quiz.model;

public class Result {
	private String tid;
	private String sid;
	private String quiz_id;
	private int quiz_total;
	private int obt_mark;
	public Result(String tid, String sid, String quiz_id, int quiz_total, int obt_mark) {
		super();
		this.tid = tid;
		this.sid = sid;
		this.quiz_id = quiz_id;
		this.quiz_total = quiz_total;
		this.obt_mark = obt_mark;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getQuiz_id() {
		return quiz_id;
	}
	public void setQuiz_id(String quiz_id) {
		this.quiz_id = quiz_id;
	}
	public int getQuiz_total() {
		return quiz_total;
	}
	public void setQuiz_total(int quiz_total) {
		this.quiz_total = quiz_total;
	}
	public int getObt_mark() {
		return obt_mark;
	}
	public void setObt_mark(int obt_mark) {
		this.obt_mark = obt_mark;
	}
}
