package com.quiz.model;

import java.util.Date;

public class Quiz_List {

	private String quiz_id;
	private String quiz_name;
	private int q_marks;
	private Date quiz_date;
	public Quiz_List(String quiz_id, String quiz_name, int q_marks, Date quiz_date) {
		super();
		this.quiz_id = quiz_id;
		this.quiz_name = quiz_name;
		this.q_marks = q_marks;
		this.quiz_date = quiz_date;
	}
	public String getQuiz_id() {
		return quiz_id;
	}
	public void setQuiz_id(String quiz_id) {
		this.quiz_id = quiz_id;
	}
	public String getQuiz_name() {
		return quiz_name;
	}
	public void setQuiz_name(String quiz_name) {
		this.quiz_name = quiz_name;
	}
	public int getQ_marks() {
		return q_marks;
	}
	public void setQ_marks(int q_marks) {
		this.q_marks = q_marks;
	}
	public Date getQuiz_date() {
		return quiz_date;
	}
	public void setQuiz_date(Date quiz_date) {
		this.quiz_date = quiz_date;
	}
	
	
}
