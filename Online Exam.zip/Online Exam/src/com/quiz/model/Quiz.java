package com.quiz.model;

import java.util.Date;

public class Quiz {

	private String tid;
	private String did;
	private String clg_id;
	private String quiz_id;
	private String quiz_name;
	private String qname;
	private String op_1;
	private String op_2;
	private String op_3;
	private String op_4;
	private String correct_ans;
	private int q_marks;
	private String q_pub_time;
	private String q_dur;
	private Date reg_date;

	private String stud_ans;
	
	public Quiz(String tid, String did, String clg_id, String quiz_id, String quiz_name, String qname, String op_1,
			String op_2, String op_3, String op_4, String correct_ans, int q_marks) {
		super();
		this.tid = tid;
		this.did = did;
		this.clg_id = clg_id;
		this.quiz_id = quiz_id;
		this.quiz_name = quiz_name;
		this.qname = qname;
		this.op_1 = op_1;
		this.op_2 = op_2;
		this.op_3 = op_3;
		this.op_4 = op_4;
		this.correct_ans = correct_ans;
		this.q_marks = q_marks;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getDid() {
		return did;
	}
	public void setDid(String did) {
		this.did = did;
	}
	public String getClg_id() {
		return clg_id;
	}
	public void setClg_id(String clg_id) {
		this.clg_id = clg_id;
	}
	public String getQuiz_id() {
		return quiz_id;
	}
	public void setQuiz_id(String quiz_id) {
		this.quiz_id = quiz_id;
	}
	public String getQuiz_name() {
		return quiz_name;
	}
	public void setQuiz_name(String quiz_name) {
		this.quiz_name = quiz_name;
	}
	public String getQname() {
		return qname;
	}
	public void setQname(String qname) {
		this.qname = qname;
	}
	public String getOp_1() {
		return op_1;
	}
	public void setOp_1(String op_1) {
		this.op_1 = op_1;
	}
	public String getOp_2() {
		return op_2;
	}
	public void setOp_2(String op_2) {
		this.op_2 = op_2;
	}
	public String getOp_3() {
		return op_3;
	}
	public void setOp_3(String op_3) {
		this.op_3 = op_3;
	}
	public String getOp_4() {
		return op_4;
	}
	public void setOp_4(String op_4) {
		this.op_4 = op_4;
	}
	public String getCorrect_ans() {
		return correct_ans;
	}
	public void setCorrect_ans(String correct_ans) {
		this.correct_ans = correct_ans;
	}
	public int getQ_marks() {
		return q_marks;
	}
	public void setQ_marks(int q_marks) {
		this.q_marks = q_marks;
	}
	public String getQ_pub_time() {
		return q_pub_time;
	}
	public void setQ_pub_time(String q_pub_time) {
		this.q_pub_time = q_pub_time;
	}
	public String getQ_dur() {
		return q_dur;
	}
	public void setQ_dur(String q_dur) {
		this.q_dur = q_dur;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
	public String getStud_ans() {
		return stud_ans;
	}
	public void setStud_ans(String stud_ans) {
		this.stud_ans = stud_ans;
	}
	
}
