package com.quiz.model;

import java.sql.Date;

public class Subject {
	private String tid;
	private String did;
	private String clg_id;
	private String sub_id;
	private String sub_name;
	private String q_status;
	private String visibility;
	private Date reg_date;
	
	private String q_pub_time;
	private String q_dur;
	private int quiz_marks;
	public Subject(String tid,String did,String clg_id, String sub_id, String sub_name) {
		super();
		this.tid = tid;
		this.did = did;
		this.clg_id = clg_id;
		this.sub_id = sub_id;
		this.sub_name = sub_name;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getDid() {
		return did;
	}
	public void setDid(String did) {
		this.did = did;
	}
	public String getClg_id() {
		return clg_id;
	}
	public void setClg_id(String clg_id) {
		this.clg_id = clg_id;
	}
	public String getSub_id() {
		return sub_id;
	}
	public void setSub_id(String sub_id) {
		this.sub_id = sub_id;
	}
	public String getSub_name() {
		return sub_name;
	}
	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	}
	public String getQ_status() {
		return q_status;
	}

	public void setQ_status(String q_status) {
		this.q_status = q_status;
	}
	public String getVisibility() {
		return visibility;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
	public String getQ_pub_time() {
		return q_pub_time;
	}
	public void setQ_pub_time(String q_pub_time) {
		this.q_pub_time = q_pub_time;
	}
	public String getQ_dur() {
		return q_dur;
	}
	public void setQ_dur(String q_dur) {
		this.q_dur = q_dur;
	}
	public int getQuiz_marks() {
		return quiz_marks;
	}
	public void setQuiz_marks(int quiz_marks) {
		this.quiz_marks = quiz_marks;
	}
	
}
