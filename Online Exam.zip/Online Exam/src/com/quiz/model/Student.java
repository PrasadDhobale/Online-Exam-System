package com.quiz.model;

import java.sql.Date;

public class Student {
	private String fname;
	private String lname;
	private String sid;
	private String did;
	private String clg_id;
	private String clg_name;
	private String email;
	private String pass;
	private Date reg_date;
	public Student(String fname, String lname, String sid, String did, String clg_id, String clg_name, String email,
			String pass) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.sid = sid;
		this.did = did;
		this.clg_id = clg_id;
		this.clg_name = clg_name;
		this.email = email;
		this.pass = pass;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getDid() {
		return did;
	}
	public void setDid(String did) {
		this.did = did;
	}
	
	public String getClg_id() {
		return clg_id;
	}
	public void setClg_id(String clg_id) {
		this.clg_id = clg_id;
	}
	public String getClg_name() {
		return clg_name;
	}
	public void setClg_name(String clg_name) {
		this.clg_name = clg_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
}
