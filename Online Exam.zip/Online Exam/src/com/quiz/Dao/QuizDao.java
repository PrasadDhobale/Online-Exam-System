package com.quiz.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.quiz.model.Decrypt;
import com.quiz.model.Encrypt;
import com.quiz.model.OConnection;
import com.quiz.model.Quiz;
import com.quiz.model.Result;

public class QuizDao{
	
	private static Connection con = null;
	OConnection db = new OConnection();
	Encrypt en = new Encrypt();
	Decrypt de = new Decrypt();
	
	public int create_Quiz(List<Quiz> qlist,String q_pub_time,String time) {
		int i = 0;
		con = db.getConnection();
		String quiz_id = null;
		String tid = null;
		try {
			
			PreparedStatement ps = con.prepareStatement("insert into q_quiz values(?,?,?,?,?,?,?,?,?,?,?,?,to_date(?,'yyyy/mm/dd HH24:MI:SS'),?,systimestamp)");
			for (Quiz q : qlist) {
				q = en.quizencrypt(q);
				quiz_id = q.getQuiz_id();
				tid = q.getTid();
				
				ps.setString(1, q.getTid());
				ps.setString(2, q.getDid());
				ps.setString(3, q.getClg_id());
				ps.setString(4, q.getQuiz_id());
				ps.setString(5, q.getQuiz_name());
				ps.setString(6, q.getQname());
				ps.setString(7, q.getOp_1());
				ps.setString(8, q.getOp_2());
				ps.setString(9, q.getOp_3());
				ps.setString(10, q.getOp_4());
				ps.setString(11, q.getCorrect_ans());
				ps.setInt(12, q.getQ_marks());
				ps.setString(13, q_pub_time);
				ps.setString(14, time);
				i = ps.executeUpdate();
			}
			if(i > 0) {
				ps = con.prepareStatement("update q_subject set q_status = 'Active' where sub_id = ?");
				ps.setString(1, quiz_id);
				i = ps.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int quiz_counter(String tid) {
		int qc = 0;
		con = db.getConnection();
		try {
			tid = en.encryptstring(tid);
			System.out.println(tid);
			PreparedStatement ps = con.prepareStatement("select count(distinct quiz_id) from q_quiz where teach_id = ?");
			ps.setString(1, tid);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				qc = rs.getInt(1); 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return qc;
	}
	public LinkedList<Quiz> getTQuiz(String tid,String quiz_id){
		LinkedList<Quiz> quiz_list = new LinkedList<Quiz>();
		con = db.getConnection();
		try {
			tid = en.encryptstring(tid);
			quiz_id = en.encryptstring(quiz_id);
			PreparedStatement ps = con.prepareStatement("select TEACH_ID,DEPT_ID,CLGID,QUIZ_ID,QUIZ_NAME,Q_NAME,OP_1,OP_2,OP_3,OP_4,CORR_ANS,Q_MARK,to_char(q_pub_time,'mon dd yyyy HH24:MI:SS'),Q_DUR,REG_DATE from q_quiz where teach_id = ? and quiz_id = ?");
			ps.setString(1, tid);
			ps.setString(2, quiz_id);
			ResultSet rs = ps.executeQuery();
			if(!rs.next()) {
				quiz_list = null;
			}else {
				do {
					Quiz q = new Quiz(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10),String.valueOf(rs.getInt(11)+1), rs.getInt(12));
					q = de.quizdecrypt(q);
					q.setQ_pub_time(rs.getString(13));
					q.setQ_dur(rs.getString(14));
					q.setReg_date(rs.getDate(15));
					quiz_list.add(q);
				}while(rs.next());					
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return quiz_list;
	}
	public int edittiming(String tid, String quiz_id, String q_pub_time, String q_dur) {
		int i = 0;
		con = db.getConnection();
		try {
			tid = en.encryptstring(tid);
			quiz_id = en.encryptstring(quiz_id);
			PreparedStatement ps = con.prepareStatement("update q_quiz set q_pub_time = to_date(?,'yyyy/mm/dd HH24:MI:SS'), q_dur = ? where teach_id = ? and quiz_id = ?");
			ps.setString(1, q_pub_time);
			ps.setString(2, q_dur);
			ps.setString(3, tid);
			ps.setString(4, quiz_id);
			i = ps.executeUpdate();
			System.out.println(i);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public int delete_question(String tid, String quiz_id, String q_name) {
		int i = 0;
		con = db.getConnection();
		try {
			tid = en.encryptstring(tid);
			quiz_id = en.encryptstring(quiz_id);
			q_name = en.encryptstring(q_name);
			
			PreparedStatement ps = con.prepareStatement("delete from q_quiz where q_name = ? and quiz_id = ? and teach_id = ?");
			ps.setString(1, q_name);
			ps.setString(2, quiz_id);
			ps.setString(3, tid);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return i;
	}
	public int add_que(Quiz q,String q_pub_time,String q_dur) {
		int i = 0;
		con = db.getConnection();
		try {
			q = en.quizencrypt(q);
			PreparedStatement ps = con.prepareStatement("insert into q_quiz values(?,?,?,?,?,?,?,?,?,?,?,?,to_date(?,'mon/dd/yyyy HH24:MI:SS'),?,systimestamp)");
			ps.setString(1, q.getTid());
			ps.setString(2, q.getDid());
			ps.setString(3, q.getClg_id());
			ps.setString(4, q.getQuiz_id());
			ps.setString(5, q.getQuiz_name());
			ps.setString(6, q.getQname());
			ps.setString(7, q.getOp_1());
			ps.setString(8, q.getOp_2());
			ps.setString(9, q.getOp_3());
			ps.setString(10, q.getOp_4());
			ps.setString(11, q.getCorrect_ans());
			ps.setInt(12, q.getQ_marks());
			ps.setString(13, q_pub_time);
			ps.setString(14, q_dur);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public int edit_question(Quiz q, String oq_name) {
		int i = 0;
		con = db.getConnection();
		try {
			q = en.quizencrypt(q);
			oq_name = en.encryptstring(oq_name);
			PreparedStatement ps = con.prepareStatement("update q_quiz set q_name = ?,op_1 = ?,op_2 = ?,op_3 = ?,op_4 = ?,corr_ans = ?,q_mark = ? where quiz_id = ? and q_name = ? and teach_id = ? and dept_id = ? and clgid = ?");
			ps.setString(1, q.getQname());
			ps.setString(2, q.getOp_1());
			ps.setString(3, q.getOp_2());
			ps.setString(4, q.getOp_3());
			ps.setString(5, q.getOp_4());
			ps.setString(6, q.getCorrect_ans());
			ps.setInt(7, q.getQ_marks());
			ps.setString(8, q.getQuiz_id());
			ps.setString(9, oq_name);
			ps.setString(10, q.getTid());
			ps.setString(11, q.getDid());
			ps.setString(12, q.getClg_id());
			i = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return i;
	}
	public int del_Quiz(String tid, String quiz_id) {
		int i = 0;
		con = db.getConnection();
		try {
			tid = en.encryptstring(tid);
			quiz_id = en.encryptstring(quiz_id);
			PreparedStatement ps = con.prepareStatement("delete from q_quiz where teach_id = ? and quiz_id =?");
			ps.setString(1, tid);
			ps.setString(2, quiz_id);
			i = ps.executeUpdate();
			if(i > 0) {
				ps = con.prepareStatement("update q_subject set q_status = 'Inactive' where tid = ? and sub_id = ?");
				ps.setString(1, tid);
				ps.setString(2, quiz_id);
				ps.execute();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public LinkedList<Quiz> getDQuiz(String did, String quiz_id) {
		LinkedList<Quiz> quiz_list = new LinkedList<Quiz>();
		con = db.getConnection();
		try {
			did = en.encryptstring(did);
			quiz_id = en.encryptstring(quiz_id);
			PreparedStatement ps = con.prepareStatement("select TEACH_ID,DEPT_ID,CLGID,QUIZ_ID,QUIZ_NAME,Q_NAME,OP_1,OP_2,OP_3,OP_4,CORR_ANS,Q_MARK,to_char(q_pub_time,'mon dd yyyy HH24:MI:SS'),Q_DUR,REG_DATE from q_quiz where dept_id = ? and quiz_id = ?");
			ps.setString(1, did);
			ps.setString(2, quiz_id);
			ResultSet rs = ps.executeQuery();
			if(!rs.next()) {
				quiz_list = null;
			}else {
				do {
					Quiz q = new Quiz(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10),String.valueOf(rs.getInt(11)+1), rs.getInt(12));
					q = de.quizdecrypt(q);
					q.setQ_pub_time(rs.getString(13));
					q.setQ_dur(rs.getString(14));
					q.setReg_date(rs.getDate(15));
					quiz_list.add(q);
				}while(rs.next());					
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return quiz_list;
	}
	public int stud_response(LinkedList<Quiz> s_response) {
		int i = 0;
		con = db.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("insert into q_s_response values(?,?,?,?,?,?,?,?,?,?,?,?,?,systimestamp)");
			for(Quiz  q : s_response) {
				
				ps.setString(1, q.getTid());
				ps.setString(2, q.getDid());
				ps.setString(3, q.getClg_id());
				ps.setString(4, q.getQuiz_id());
				ps.setString(5, q.getQuiz_name());
				ps.setString(6, q.getQname());
				ps.setString(7, q.getOp_1());
				ps.setString(8, q.getOp_2());
				ps.setString(9, q.getOp_3());
				ps.setString(10, q.getOp_4());
				ps.setString(11, q.getCorrect_ans());
				ps.setInt(12, q.getQ_marks());
				ps.setString(13, q.getStud_ans());
				i = ps.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int q_result(String sid,String tid,String did,String clg_id,String quiz_id,int total_mark,int marks_obt) {
		int i = 0;
		con = db.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("insert into q_result values(?,?,?,?,?,?,?,systimestamp)");
			ps.setString(1, sid);
			ps.setString(2, tid);
			ps.setString(3, did);
			ps.setString(4, clg_id);
			ps.setString(5, quiz_id);
			ps.setInt(6, total_mark);
			ps.setInt(7, marks_obt);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int q_comp_status(String sid,String quiz_id) {
		int i = 0;
		con = db.getConnection();
		try {
			System.out.println(sid+"\t"+quiz_id);
			PreparedStatement ps = con.prepareStatement("select *from q_result where sid = ? and quiz_id = ?");
			ps.setString(1, sid);
			ps.setString(2, quiz_id);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public LinkedList<Result> getResult(String tid,String quiz_id) {
		LinkedList<Result> result = new LinkedList<Result>();
		con = db.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("select *from q_result where tid = ? and quiz_id = ?");
			ps.setString(1, tid);
			ps.setString(2, quiz_id);
			ResultSet rs = ps.executeQuery();
			if(!rs.next()) {
				result = null;
			}else {
				do {
					Result r = new Result(rs.getString(2), rs.getString(1), rs.getString(5), rs.getInt(6), rs.getInt(7));
					result.add(r);
				}while(rs.next());					
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	public LinkedList<Result> getS_Result(String sid) {
		LinkedList<Result> result = new LinkedList<Result>();
		con = db.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("select *from q_result where sid = ?");
			ps.setString(1, sid);
			ResultSet rs = ps.executeQuery();
			if(!rs.next()) {
				result = null;
			}else {
				do {
					Result r = new Result(rs.getString(2), rs.getString(1), rs.getString(5), rs.getInt(6), rs.getInt(7));
					result.add(r);
				}while(rs.next());					
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	public LinkedList<Quiz> getResponse(String sid,String quiz_id){
		LinkedList<Quiz> s_response = new LinkedList<Quiz>();
		con = db.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("select *from q_s_response where sid = ? and quiz_id = ?");
			ps.setString(1, sid);
			ps.setString(2, quiz_id);
			ResultSet rs = ps.executeQuery();
			if(!rs.next()) {
				s_response = null;
			}else {
				do {
					Quiz q = new Quiz(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), String.valueOf(rs.getInt(11)+1), rs.getInt(12));
					q.setStud_ans(String.valueOf(rs.getInt(13)+1));
					s_response.add(q);
				}while(rs.next());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s_response;
	}
	
}