package com.quiz.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import com.quiz.model.Decrypt;
import com.quiz.model.Email_Sender;
import com.quiz.model.Encrypt;
import com.quiz.model.OConnection;
import com.quiz.model.Student;
import com.quiz.model.Subject;
import com.quiz.model.Teacher;
//import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import oracle.jdbc.proxy.annotation.Pre;

public class TeacherDao {
	Connection con = null;
	OConnection db = new OConnection();
	Encrypt en = new Encrypt();
	Decrypt de = new Decrypt();
	
	
	public int teacher_register(Teacher t){
		con = db.getConnection();
		int i = 0;
		try {
			String email = t.getEmail();
			String message = "Hello "+t.getFname()+" "+t.getLname()+" !! Thanks For Registering With Online Exam.";
			
			t = en.tencrypt(t);
			
			PreparedStatement ps = con.prepareStatement("insert into q_teach values (?,?,?,?,?,?,?,'Inactive',?,sysdate)");
			ps.setString(1, t.getFname());
			ps.setString(2, t.getLname());
			ps.setString(3, t.getTid());
			ps.setString(4, t.getDid());
			ps.setString(5, t.getClg_id());
			ps.setString(6, t.getClg_name());
			ps.setString(7, t.getEmail());
			ps.setString(8, t.getPass());
			
			i =ps.executeUpdate();
			if(i > 0) {
				String vlink = "http://localhost:8081/Online_Exam/Ev?email="+t.getEmail()+"&id="+t.getTid()+"&r=t";
				Email_Sender es = new Email_Sender();
				es.sendEmail(message, vlink, "Online Exam : Email Verification", email, "v");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int checktid_email(String tid,String email) {
		int i = 0;
		con = db.getConnection();
		try {
			tid = en.encryptstring(tid);
			email = en.encryptstring(email);
			PreparedStatement ps = con.prepareStatement("select * from q_teach where tid = ? or email = ?");
			ps.setString(1, tid);
			ps.setString(2, email);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int verifyid_email(String tid,String email) {
		int i = 0;
		con = db.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("select * from q_teach where tid = ? and email = ?");
			ps.setString(1, tid);
			ps.setString(2, email);
			i = ps.executeUpdate();
			if(i > 0) {
				i = 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int email_verified(String tid) {
		con = db.getConnection();
		int i = 0;
		try {
			PreparedStatement ps = con.prepareStatement("update q_teach set evs = 'Active' where tid = ?");
			ps.setString(1, tid);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public String checkeverification(String tidemail) {
		con = db.getConnection();		
		PreparedStatement ps;
		String tid = null;
		try {
			tidemail = en.encryptstring(tidemail);			
			ps = con.prepareStatement("select evs,tid from q_teach where email = ? or tid = ?");
			ps.setString(1, tidemail);
			ps.setString(2, tidemail);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				tid = rs.getString(2);
				if(rs.getString(1).equals("Active")) {
					tid = "Active";
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tid;
	}
	public Teacher sevl(String id) {
		con = db.getConnection();
		Teacher t = null;
		try {
			PreparedStatement ps = con.prepareStatement("select *from q_teach where tid = ?");
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				t = new Teacher(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(9));
				Email_Sender es = new Email_Sender();
				String vlink = "http://localhost:8081/Online_Exam/Ev?email="+t.getEmail()+"&id="+t.getTid()+"&r=t";
				int i = es.sendEmail("Hello Dear !! Thanks For Registering With Online Exam.", vlink, "Online Exam : Email Verification", de.decryptstring(t.getEmail()), "v");
				if(i==0) {
					t = null;
				}
				t = de.tdecrypt(t);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return t;
	}
	public Teacher Login(String tidemail,String pass) {
		Teacher t = null;
		con = db.getConnection();
		try {
			tidemail = en.encryptstring(tidemail);
			pass = en.encryptstring(pass);
			
			PreparedStatement ps = con.prepareStatement("select *from q_teach where (password = ? and email = ?) or (tid = ? and password = ?)");
			ps.setString(1, pass);
			ps.setString(2, tidemail);
			ps.setString(3, tidemail);
			ps.setString(4, pass);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				t = new Teacher(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(9));
				t = de.tdecrypt(t);
				t.setReg_date(rs.getDate(10));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return t;
	}
	public int sendpass(String email) {
		int i = 0;
		con =db.getConnection();
		try {
			email = en.encryptstring(email);
			PreparedStatement ps = con.prepareStatement("Select tid,password from q_teach where email = ?");
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				String tid = rs.getString(1);
				String pass = de.decryptstring(rs.getString(2));
				
				Email_Sender es = new Email_Sender();
				i = es.sendEmail("Hello Dear !! Thanks For Registering With Online Exam.Your Password Is : ", pass, "Online Exam : Forgot Password", de.decryptstring(email), "fp");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public Teacher tprofile(String email) {
		con =db.getConnection();
		Teacher t = null;
		try {
			email = en.encryptstring(email);
			PreparedStatement ps = con.prepareStatement("select *from q_teach where email = ? or tid = ?");
			ps.setString(1, email);
			ps.setString(2, email);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				t = new Teacher(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(9));
				t = de.tdecrypt(t);
				t.setReg_date(rs.getDate(10));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return t;
	}
	public Teacher tprofileupdate(Teacher t) {
		con = db.getConnection();
		int i = 0;
		try {
			t = en.tencrypt(t);
			PreparedStatement ps = con.prepareStatement("update q_teach set fname=?,lname=?,tid=?,did=?,clg_id=?,clg_name=?,password=? where email = ?");
			ps.setString(1, t.getFname());
			ps.setString(2, t.getLname());
			ps.setString(3, t.getTid());
			ps.setString(4, t.getDid());
			ps.setString(5, t.getClg_id());
			ps.setString(6, t.getClg_name());			
			ps.setString(7, t.getPass());
			ps.setString(8, t.getEmail());
			i = ps.executeUpdate();
			if(i> 0) {				
				t = tprofile(de.decryptstring(t.getEmail()));				
			}else {
				t = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return t;
	}
	public int sendtpdl(String email,String pass) {
		con = db.getConnection();
		int i =0;
		try {
			email = en.encryptstring(email);
			pass = en.encryptstring(pass);
			PreparedStatement ps = con.prepareStatement("select email,tid from q_teach where email = ? and password = ?");
			ps.setString(1, email);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				i = 1;
				String dlink = "http://localhost:8081/Online_Exam/Dt?email="+rs.getString(1)+"&id="+rs.getString(2)+"&r=t";
				Email_Sender es = new Email_Sender();
				i = es.sendEmail("Hello Dear !! Thanks For Registering With Online Exam ", dlink, "Online Exam : Delete Profile", de.decryptstring(email), "d");
				if(i > 0) {
					i = 5;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return i;
	}
	public int  deleteteacher(String email) {
		int i = 0;		
		con = db.getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement("delete from q_subject where tid = (select tid from q_teach where email = ?)");
			ps.setString(1, email);
			ps.execute();
			PreparedStatement pst = con.prepareStatement("delete from q_teach where email = ?");
			pst.setString(1, email);
			i = pst.executeUpdate();
		
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public Teacher tcp(String tid,String newpass) {
		int i = 0;
		con = db.getConnection();
		Teacher t = null;
		try {
			tid = en.encryptstring(tid);
			newpass  = en.encryptstring(newpass);			
			PreparedStatement ps = con.prepareStatement("update q_teach set password = ? where tid = ?");
			ps.setString(1, newpass);
			ps.setString(2, tid);
			i = ps.executeUpdate();
			if(i > 0) {
				t = new Teacher("", "", "", "", "", "", "", "");
				t = tprofile(de.decryptstring(tid));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return t;		
	}
	public LinkedList<Teacher> otherteacher(String clg_id,String tid){
		LinkedList<Teacher> tlist=new LinkedList<Teacher>();
		con=db.getConnection();
		try {
			clg_id = en.encryptstring(clg_id);
			tid = en.encryptstring(tid);
			PreparedStatement ps = con.prepareStatement("select * from q_teach where clg_id = ? and  not tid = ?");
			ps.setString(1, clg_id);
			ps.setString(2, tid);
			ResultSet rs = ps.executeQuery();
			if (rs.next() == false) {
				tlist = null;
			} else {
				do {
					Teacher t = new Teacher(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(9));
					t = de.tdecrypt(t);
					t.setReg_date(rs.getDate(10));
					tlist.add(t);
				}while (rs.next()); 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tlist;
	}
	public LinkedList<Student> AllStudents(String clg_id,String did){
		LinkedList<Student> slist = new LinkedList<Student>();
		con = db.getConnection();
		try {
			clg_id = en.encryptstring(clg_id);
			did = en.encryptstring(did);
			PreparedStatement ps = con.prepareStatement("select *from q_Student where clg_id = ? and did = ?");
			ps.setString(1, clg_id);
			ps.setString(2, did);
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				slist = null;
			} else {
				do {
					Student s = new Student(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(9));
					s = de.sdecrypt(s);
					s.setReg_date(rs.getDate(10));
					slist.add(s);
				}while (rs.next()); 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return slist;
	}
	public int sub_register(Subject s) {
		int i = 0;
		con = db.getConnection();
		try {
			s = en.subencrypt(s);
			PreparedStatement ps = con.prepareStatement("insert into q_subject values (?,?,?,?,?,'Inactive','Private',sysdate)");
			ps.setString(1, s.getTid());
			ps.setString(2, s.getDid());
			ps.setString(3, s.getClg_id());
			ps.setString(4, s.getSub_id());
			ps.setString(5, s.getSub_name());
			i = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public int checksub_id(String sub_id,String clg_id) {
		int i = 0;
		con = db.getConnection();
		try {
			sub_id = en.encryptstring(sub_id);
			clg_id = en.encryptstring(clg_id);
			PreparedStatement ps = con.prepareStatement("select *from q_subject where sub_id = ? and clg_id = ?");
			ps.setString(1, sub_id);
			ps.setString(2, clg_id);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public LinkedList<Subject> AlltSubjects(String tid){
		LinkedList<Subject> sub_list = new LinkedList<Subject>();
		con = db.getConnection();
		try {
			tid = en.encryptstring(tid);
			PreparedStatement ps = con.prepareStatement("select *from q_subject where tid = ?");
			ps.setString(1, tid);
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				sub_list = null;
			} else {
				do {
					Subject s = new Subject(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
					s = de.subdecrypt(s);
					s.setQ_status(rs.getString(6));
					s.setVisibility(rs.getString(7));
					s.setReg_date(rs.getDate(8));
					
					sub_list.add(s);
				}while (rs.next());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sub_list;
	}
	public LinkedList<Subject> AllinactiveSubjects(String tid){
		LinkedList<Subject> sub_list = new LinkedList<Subject>();
		con = db.getConnection();
		try {
			tid = en.encryptstring(tid);
			PreparedStatement ps = con.prepareStatement("select *from q_subject where tid = ? and q_status='Inactive'");
			ps.setString(1, tid);
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				sub_list = null;
			} else {
				do {
					Subject s = new Subject(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
					s = de.subdecrypt(s);
					s.setQ_status(rs.getString(6));
					s.setVisibility(rs.getString(7));
					s.setReg_date(rs.getDate(8));
					sub_list.add(s);
				}while (rs.next());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sub_list;
	}
	public LinkedList<Subject> AllactiveSubjects(String tid){
		LinkedList<Subject> sub_list = new LinkedList<Subject>();
		con = db.getConnection();
		try {
			tid = en.encryptstring(tid);
						
			PreparedStatement ps = con.prepareStatement("SELECT distinct s.tid,s.did,s.clg_id,s.sub_id,s.sub_name,s.q_status,s.visibility,to_char(q.q_pub_time,'mon dd yyyy HH24:MI:SS'),q.q_dur FROM q_subject s,q_quiz q where s.sub_id = q.quiz_id and q_status = 'Active' and s.tid = ?");
			ps.setString(1, tid);
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				sub_list = null;
			} else {
				do {
					Subject s = new Subject(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
					s = de.subdecrypt(s);
					s.setQ_status(rs.getString(6));
					s.setVisibility(rs.getString(7));
					s.setQ_pub_time(rs.getString(8));
					s.setQ_dur(rs.getString(9));
					
					int quiz_marks = 0;
					
					ps = con.prepareStatement("select distinct sum(q_mark-32) from q_quiz where tid = ? and quiz_id = ?");
					ps.setString(1, tid);
					ps.setString(2, rs.getString(4));
					ResultSet rs2 = ps.executeQuery();
					if(rs2.next()) {
						quiz_marks = rs2.getInt(1);
					}
					s.setQuiz_marks(quiz_marks);
					
					sub_list.add(s);
				}while (rs.next());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sub_list;
	}
	public LinkedList<Subject> AlldSubjects(String did, String clg_id){
		LinkedList<Subject> sub_list = new LinkedList<Subject>();
		con = db.getConnection();
		try {
			did = en.encryptstring(did);
			clg_id = en.encryptstring(clg_id);
			PreparedStatement ps = con.prepareStatement("select *from q_subject where did = ? and clg_id = ?");
			ps.setString(1, did);
			ps.setString(2, clg_id);
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				sub_list = null;
			} else {
				do {
					Subject s = new Subject(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
					s = de.subdecrypt(s);
					s.setQ_status(rs.getString(6));
					s.setVisibility(rs.getString(7));
					s.setReg_date(rs.getDate(8));
					sub_list.add(s);
				}while (rs.next());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sub_list;
	}
	public int check_student(String sid,String did,String clg_id) {
		int i = 0;
		con = db.getConnection();
		try {			
			sid = en.encryptstring(sid);
			did = en.encryptstring(did);
			clg_id = en.encryptstring(clg_id);
			PreparedStatement ps = con.prepareStatement("select * from q_student where sid = ? and did = ? and clg_id = ?");
			ps.setString(1, sid);
			ps.setString(2, did);
			ps.setString(3, clg_id);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int delete_student(String sid) {
		int i = 0;
		con = db.getConnection();
		try {
			sid= en.encryptstring(sid);
			PreparedStatement ps = con.prepareStatement("delete from q_student where sid = ?");
			ps.setString(1, sid);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int store_reason(String tid,String did,String clg_id,String sid, String reason) {
		int i = 0;
		con = db.getConnection();
		try {
			
			tid= en.encryptstring(tid);
			did= en.encryptstring(did);
			clg_id= en.encryptstring(clg_id);
			sid= en.encryptstring(sid);
			reason = en.encryptstring(reason);
			PreparedStatement ps = con.prepareStatement("insert into q_reason values(?,?,?,?,?,sysdate)");
			ps.setString(1, tid);
			ps.setString(2, did);
			ps.setString(3, clg_id);
			ps.setString(4, sid);
			ps.setString(5, reason);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int sendwarn(String tid, String email, String sid, String reason) {
		int i = 0;
		con = db.getConnection();
		try {
			sid=  en.encryptstring(sid);
			PreparedStatement ps = con.prepareStatement("select *from q_student where sid = ?");
			ps.setString(1, sid);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				String message = "Hello "+de.decryptstring(rs.getString(1))+"!! This is the Warning From Online Quiz For Your Misbehaviour.<br>Warning : "+reason+".<br>For more information Contact Your Teacher <br>"+email+".<br>";
				String content = "http://localhost:8081/Online_Exam/";
				Email_Sender es = new Email_Sender();
				i = es.sendEmail(message, content, "Online Exam : Warning",de.decryptstring(rs.getString(7)) ,"sw");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int update_subject(String sub_id, String sub_name) {
		int i = 0;
		con = db.getConnection();
		try {
			sub_id = en.encryptstring(sub_id);
			sub_name = en.encryptstring(sub_name);
			PreparedStatement ps = con.prepareStatement("update q_subject set sub_name = ? where sub_id = ?");
			ps.setString(1, sub_name);
			ps.setString(2, sub_id);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public int delete_subject(String sub_id) {
		int i = 0;
		con = db.getConnection();
		try {
			sub_id = en.encryptstring(sub_id);
			System.out.println(sub_id);
			PreparedStatement ps = con.prepareStatement("delete from q_subject where sub_id = ?");
			ps.setString(1, sub_id);;
			i = ps.executeUpdate();
			if(i > 0) {
				ps = con.prepareStatement("delete from q_quiz where quiz_id = ?");
				ps.setString(1, sub_id);
				ps.execute();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public LinkedList<Student> SearchStudent(String did,String search) {
		LinkedList<Student> search_list = new LinkedList<Student>();
		con = db.getConnection();
		try {
			did = en.encryptstring(did);
			search = en.encryptstring(search);
			PreparedStatement ps = con.prepareStatement("select *from q_student where did = ? and fname like ? or lname like ? or sid like ? or email like ?");
			ps.setString(1, did);
			ps.setString(2, "%"+search+"%");
			ps.setString(3, "%"+search+"%");
			ps.setString(4, "%"+search+"%");
			ps.setString(5, "%"+search+"%");
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				search_list = null;
			} else {
				do {
					Student s = new Student(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(9));
					s = de.sdecrypt(s);
					s.setReg_date(rs.getDate(10));
					search_list.add(s);
				}while (rs.next()); 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return search_list;
	}
}