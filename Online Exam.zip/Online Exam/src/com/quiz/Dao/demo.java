package com.quiz.Dao;

public class demo {

	public static void main(String[] args) {

		int [] arr = new int [] {1, 3, 4, 8, 3 ,3};   

		System.out.println("Duplicate elements in given array: ");  
		int f = 0;
		for(int i = 0; i < arr.length; i++) {  
			for(int j = i + 1; j < arr.length; j++) {  
				if(arr[i] == arr[j]) {					
					System.out.println(arr[j] +" repeated");
					break;
				}else {
					System.out.println(arr[j]+" Not Repeated");
				}
			}  
		}

	}

}
