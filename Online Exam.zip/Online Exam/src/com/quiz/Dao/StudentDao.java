package com.quiz.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

import com.quiz.model.Decrypt;
import com.quiz.model.Email_Sender;
import com.quiz.model.Encrypt;
import com.quiz.model.OConnection;
import com.quiz.model.Student;
import com.quiz.model.Subject;
import com.quiz.model.Teacher;

public class StudentDao {
	Connection con = null;
	OConnection db = new OConnection();
	Encrypt en = new Encrypt();
	Decrypt de = new Decrypt();

	public int student_register(Student s){
		con =db.getConnection();
		int i = 0;
		try {
			String email = s.getEmail();
			String message = "Hello "+s.getFname()+" "+s.getLname()+" !! Thanks For Registering With Online Quiz.";
			s = en.sencrypt(s);
			PreparedStatement ps = con.prepareStatement("insert into q_student values (?,?,?,?,?,?,?,'Inactive',?,sysdate)");
			ps.setString(1, s.getFname());
			ps.setString(2, s.getLname());
			ps.setString(3, s.getSid());
			ps.setString(4, s.getDid());
			ps.setString(5, s.getClg_id());
			ps.setString(6, s.getClg_name());
			ps.setString(7, s.getEmail());
			ps.setString(8, s.getPass());
			
			i =ps.executeUpdate();
			if(i > 0) {
				String vlink = "http://localhost:8081/Online_Exam/Ev?email="+s.getEmail()+"&id="+s.getSid()+"&r=s";
				Email_Sender es = new Email_Sender();
				es.sendEmail(message, vlink, "Online Exam : Email Verification", email, "v");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int checktid_email(String sid,String email) {
		int i = 0;
		con = db.getConnection();
		try {			
			sid = en.encryptstring(sid);
			email = en.encryptstring(email);
			PreparedStatement ps = con.prepareStatement("select * from q_student where sid = ? or email = ?");
			ps.setString(1, sid);
			ps.setString(2, email);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int verifyid_email(String sid,String email) {
		int i = 0;
		con = db.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("select * from q_student where sid = ? and email = ?");
			ps.setString(1, sid);
			ps.setString(2, email);
			i = ps.executeUpdate();
			if(i > 0) {
				i = 1;
				System.out.println("Email Exist");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int email_verified(String sid) {
		con = db.getConnection();
		int i = 0;
		try {
			PreparedStatement ps = con.prepareStatement("update q_student set evs = 'Active' where sid = ?");
			ps.setString(1, sid);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public String checkeverification(String sidemail) {
		con = db.getConnection();		
		PreparedStatement ps;
		String sid = null;
		try {
			sidemail = en.encryptstring(sidemail);			
			ps = con.prepareStatement("select evs,sid from q_student where email = ? or sid = ?");
			ps.setString(1, sidemail);
			ps.setString(2, sidemail);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				sid = rs.getString(2);
				if(rs.getString(1).equals("Active")) {
					sid = "Active";
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sid;
	}
	public Student sevl(String id) {
		con = db.getConnection();
		Student s = null;
		try {
			PreparedStatement ps = con.prepareStatement("select *from q_student where sid = ?");
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				s = new Student(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(9));
				Email_Sender es = new Email_Sender();
				String vlink = "http://localhost:8081/Online_Exam/Ev?email="+s.getEmail()+"&id="+s.getSid()+"&r=s";
				int i = es.sendEmail("Hello Dear !! Thanks For Registering With Online Exam.", vlink, "Online Exam : Email Verification", de.decryptstring(s.getEmail()), "v");
				if(i==0) {
					s = null;
				}
				s = de.sdecrypt(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	public Student Login(String sidemail,String pass) {
		Student s = null;
		con = db.getConnection();
		try {
			sidemail = en.encryptstring(sidemail);
			pass = en.encryptstring(pass);
			
			PreparedStatement ps = con.prepareStatement("select *from q_student where (password = ? and email = ?) or (sid = ? and password = ?)");
			ps.setString(1, pass);
			ps.setString(2, sidemail);
			ps.setString(3, sidemail);
			ps.setString(4, pass);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				s = new Student(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(9));
				s = de.sdecrypt(s);
				s.setReg_date(rs.getDate(10));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	public int sendpass(String email) {
		int i = 0;
		con =db.getConnection();
		try {
			email = en.encryptstring(email);
			PreparedStatement ps = con.prepareStatement("Select sid,password from q_student where email = ?");
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				String tid = rs.getString(1);
				String pass = de.decryptstring(rs.getString(2));
				Email_Sender es = new Email_Sender();
				i = es.sendEmail("Hello Dear !! Thanks For Registering With Online Exam.Your Password Is : ", pass, "Online Exam : Forgot Password", de.decryptstring(email), "fp");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}	
	public Student sprofile(String email) {
		con =db.getConnection();
		Student s = null;
		try {
			email = en.encryptstring(email);
			PreparedStatement ps = con.prepareStatement("select *from q_student where email = ? or sid = ?");
			ps.setString(1, email);
			ps.setString(2, email);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				s = new Student(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(9));
				s = de.sdecrypt(s);
				s.setReg_date(rs.getDate(10));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return s;
	}
	public Student sprofileupdate(Student s) {
		con = db.getConnection();
		int i = 0;
		try {
			s = en.sencrypt(s);
			PreparedStatement ps = con.prepareStatement("update q_student set fname=?,lname=?,sid=?,did=?,clg_id=?,clg_name=?,password=? where email = ?");
			ps.setString(1, s.getFname());
			ps.setString(2, s.getLname());
			ps.setString(3, s.getSid());
			ps.setString(4, s.getDid());
			ps.setString(5, s.getClg_id());
			ps.setString(6, s.getClg_name());			
			ps.setString(7, s.getPass());
			ps.setString(8, s.getEmail());
			i = ps.executeUpdate();
			if(i> 0) {
				s = sprofile(de.decryptstring(s.getEmail()));				
			}else {
				s = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	public int sendspdl(String email,String pass) {
		con = db.getConnection();
		int i =0;
		try {
			email = en.encryptstring(email);
			pass = en.encryptstring(pass);
			PreparedStatement ps = con.prepareStatement("select email,sid from q_student where email = ? and password = ?");
			ps.setString(1, email);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				i = 1;
				String dlink = "http://localhost:8081/Online_Exam/Dt?email="+rs.getString(1)+"&id="+rs.getString(2)+"&r=s";
				Email_Sender es = new Email_Sender();
				i = es.sendEmail("Hello Dear !! Thanks For Registering With Online Exam ", dlink, "Online Exam : Delete Profile", de.decryptstring(email), "d");
				if(i > 0) {
					i = 5;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return i;
	}
	public int  deletestudent(String email) {
		int i = 0;
		con = db.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("delete from q_student where email = ?");
			ps.setString(1, email);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public Student scp(String sid,String newpass) {
		int i = 0;
		con = db.getConnection();
		Student s = null;
		try {
			sid = en.encryptstring(sid);
			newpass  = en.encryptstring(newpass);
			PreparedStatement ps = con.prepareStatement("update q_student set password = ? where sid = ?");
			ps.setString(1, newpass);
			ps.setString(2, sid);
			i = ps.executeUpdate();
			if(i > 0) {
				s = new Student("", "", "", "", "", "", "", "");
				s = sprofile(de.decryptstring(sid));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	public LinkedList<Subject> AllactiveSubjects(String did){
		LinkedList<Subject> sub_list = new LinkedList<Subject>();
		con = db.getConnection();
		try {
			did = en.encryptstring(did);
						
			PreparedStatement ps = con.prepareStatement("SELECT distinct s.tid,s.did,s.clg_id,s.sub_id,s.sub_name,s.q_status,s.visibility,to_char(q.q_pub_time,'mon dd yyyy HH24:MI:SS'),q.q_dur FROM q_subject s,q_quiz q where s.sub_id = q.quiz_id and q_status = 'Active' and did = ?");
			ps.setString(1, did);
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				sub_list = null;
			} else {
				do {
					Subject s = new Subject(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
					s = de.subdecrypt(s);
					s.setQ_status(rs.getString(6));
					s.setVisibility(rs.getString(7));
					s.setQ_pub_time(rs.getString(8));
					s.setQ_dur(rs.getString(9));
					
					int quiz_marks = 0;
					
					ps = con.prepareStatement("select distinct sum(q_mark-32) from q_quiz where dept_id = ? and quiz_id = ?");
					ps.setString(1, did);
					ps.setString(2, rs.getString(4));
					ResultSet rs2 = ps.executeQuery();
					if(rs2.next()) {
						quiz_marks = rs2.getInt(1);
					}
					s.setQuiz_marks(quiz_marks);
					
					sub_list.add(s);
				}while (rs.next());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sub_list;
	}
}