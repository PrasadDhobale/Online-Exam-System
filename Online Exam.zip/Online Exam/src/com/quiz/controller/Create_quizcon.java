package com.quiz.controller;
import java.util.List;
import java.util.LinkedList;
import java.io.IOException;
import java.io.Serializable;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.Dao.TeacherDao;
import com.quiz.model.Quiz;
import com.quiz.model.Subject;
/**
 * Servlet implementation class Create_quizcon
 */
@WebServlet("/Create_quizcon")
public class Create_quizcon extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	List<Quiz> qlist=null;
	public void init()
	{
		qlist=new LinkedList<Quiz>();
	}
	public Create_quizcon() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String quiz_id = request.getParameter("quiz_id");
		String quiz_name = request.getParameter("quiz_name");
		String qname = request.getParameter("q_name");
		HttpSession hs=request.getSession(true);
		if(qname != null && quiz_name != null) {
			
			hs.setAttribute("Create_quizcon", "Active");
			
			String create_quiz= request.getParameter("create_quiz");
			String add_que= request.getParameter("add_que");
			
			String tid = request.getParameter("tid");
			String did = request.getParameter("did");
			String clg_id = request.getParameter("clg_id");
			
			String op_1 = request.getParameter("o_1");
			String op_2 = request.getParameter("o_2");
			String op_3 = request.getParameter("o_3");
			String op_4 = request.getParameter("o_4");
			String correct_ans = request.getParameter("ca");
			int q_marks  = Integer.parseInt(request.getParameter("q_marks"));
			String start_time = request.getParameter("q_pub_time");
			String time = request.getParameter("q_dur");
			
			Quiz q = null;
			int t = 0;
			System.out.println(qlist.size());
			if(qlist.size() == 0) {
				start_time = start_time.replace("T", " ");
				
				int hr = Integer.parseInt((time.split(":")[0]));
				int min = Integer.parseInt((time.split(":")[1]));
				t = (hr * 3600) + (min * 60);
				
				q = new Quiz(tid,did,clg_id,quiz_id,quiz_name,qname, op_1, op_2, op_3, op_4, correct_ans,q_marks);
				q.setQ_pub_time(start_time);
				q.setQ_dur(time);
			}else{
				q = new Quiz(tid,did,clg_id,qlist.get(0).getQuiz_id(),qlist.get(0).getQuiz_name(),qname, op_1, op_2, op_3, op_4, correct_ans,q_marks);
				q.setQ_pub_time(qlist.get(0).getQ_pub_time());
				q.setQ_dur(qlist.get(0).getQ_dur());
			}
			
			if(add_que != null) {
				qlist.add(q);
				hs.setAttribute("que_added", "Question Added to the Quiz");
				response.sendRedirect("tquiz.jsp");
				request.setAttribute("add_que", null);
			}
			else if(create_quiz != null){
				
				if(start_time != null && time != null) {

					qlist.add(q);					
					
					QuizDao qdao = new QuizDao();
					
					for(Quiz quz : qlist) {
						start_time = quz.getQ_pub_time();
						time = quz.getQ_dur();
					}
					
					int i = qdao.create_Quiz(qlist,start_time,time);
					if(i > 0) {
						TeacherDao tdao = new TeacherDao();
						LinkedList<Subject> inactivesub_list = tdao.AllinactiveSubjects(tid);
						LinkedList<Subject> activesub_list = tdao.AllactiveSubjects(tid);
						LinkedList<Subject> sub_list = tdao.AlltSubjects(tid);
						int quiz_counter = qdao.quiz_counter(tid);
						hs.setAttribute("quiz_counter", quiz_counter);
						hs.setAttribute("inactivesub_list", inactivesub_list);
						hs.setAttribute("activesub_list", activesub_list);
						hs.setAttribute("sub_list", sub_list);
						hs.setAttribute("create_quiz", "Created Successfully");
						response.sendRedirect("tsubjects.jsp");
						
					}
					qlist = new LinkedList<Quiz>();;
				}else {
					hs.setAttribute("rtd_req", "Fields Required");
				}
				request.setAttribute("create_quiz", null);
			}
		}else {
			response.sendRedirect("tquiz.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
