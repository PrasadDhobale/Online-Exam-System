package com.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.quiz.Dao.StudentDao;
import com.quiz.Dao.TeacherDao;

/**
 * Servlet implementation class Dt
 */
@WebServlet("/Dt")
public class Dt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Dt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String key = request.getParameter("id");
		if(key != null) {
			PrintWriter pw = response.getWriter();
			pw.println("<script type='text/javascript'>");
			
			String email = request.getParameter("email");
			String r = request.getParameter("r");
			if(r.equals("s")) {
				StudentDao sdao = new StudentDao();
				int sep = sdao.verifyid_email(key, email);
				if(sep > 0) {
					int i = sdao.deletestudent(email);
					if(i > 0) {
						pw.println("alert('!! Account Deleted Successfully !!');");
						pw.println("location='slr.jsp';");
						pw.println("</script>");
					}else {
						pw.println("alert('Oops !! Something Went Wrong');");
						pw.println("location='slr.jsp';");
						pw.println("</script>");
					}
				}else {
					pw.println("alert('Oops !! Something Went Wrong');");
					pw.println("location='index.jsp';");
				}
			}else {
				TeacherDao tdao = new TeacherDao();
				int tep = tdao.verifyid_email(key, email);
				if(tep > 0) {
					int i = tdao.deleteteacher(email);
					if(i > 0) {
						pw.println("alert('!! Account Deleted Successfully !!');");
						pw.println("location='tlr.jsp';");
					}else {
						pw.println("alert('Oops !! Something Went Wrong');");
						pw.println("location='tlr.jsp';");
					}
				}else {
					pw.println("alert('Oops !! Something Went Wrong');");
					pw.println("location='index.jsp';");
				}
			}
			pw.println("</script>");
		}
		else {
			response.sendRedirect("index.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
