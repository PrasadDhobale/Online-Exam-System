package com.quiz.controller;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.Dao.TeacherDao;
import com.quiz.model.Subject;

/**
 * Servlet implementation class Tdelsubject
 */
@WebServlet("/Tdelsubject")
public class Tdelsubject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Tdelsubject() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tid = request.getParameter("tid");
		if (tid != null) {
			String sub_id = request.getParameter("sub_id");
			HttpSession hs = request.getSession(true);
			hs.setAttribute("Tdelsubject", "Active");
			TeacherDao tdao = new TeacherDao();
			int delsub = tdao.delete_subject(sub_id);
			if(delsub > 0) {
				LinkedList<Subject> sub_list = tdao.AlltSubjects(tid);
				int sub_count = 0;
				if(sub_list != null) {
					sub_count = sub_list.size();
				}
				QuizDao qdao = new QuizDao();
				int quiz_counter = qdao.quiz_counter(tid);
				hs.setAttribute("quiz_counter", quiz_counter);
				hs.setAttribute("sub_count", sub_count);
				hs.setAttribute("sub_list", sub_list);
				hs.setAttribute("delsub_status", "Subject Deleted Successfully !!");
			}
		}
		response.sendRedirect("tsubjects.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
