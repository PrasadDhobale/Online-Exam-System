package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.model.Quiz;

/**
 * Servlet implementation class Tadd_que
 */
@WebServlet("/Tadd_que")
public class Tadd_que extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Tadd_que() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String quiz_id = request.getParameter("quiz_id");
		String qname = request.getParameter("q_name");
		if(quiz_id != null) {
			HttpSession hs=request.getSession(true);
			String tid = request.getParameter("tid");
			String did = request.getParameter("did");
			String clg_id = request.getParameter("clg_id");
			
			String op_1 = request.getParameter("o_1");
			String op_2 = request.getParameter("o_2");
			String op_3 = request.getParameter("o_3");
			String op_4 = request.getParameter("o_4");
			String correct_ans = request.getParameter("ca");
			int q_marks  = Integer.parseInt(request.getParameter("q_marks"));
			String start_time = request.getParameter("q_pub_time");
			String time = request.getParameter("q_dur");
			
			QuizDao qdao = new QuizDao();
			Quiz q = new Quiz(tid, did, clg_id, quiz_id, "extra_added", qname, op_1, op_2, op_3, op_4, correct_ans, q_marks);
			q.setQ_pub_time(start_time);
			q.setQ_dur(time);
			int aq = qdao.add_que(q,start_time,time);
			LinkedList<Quiz> quiz_list = qdao.getTQuiz(tid,quiz_id);
			hs.setAttribute("quiz_list", quiz_list);
			response.sendRedirect("tquizdetails.jsp");
		}else {
			response.sendRedirect("tdashboard.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
