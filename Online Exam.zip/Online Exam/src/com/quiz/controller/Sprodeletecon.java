package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.StudentDao;

/**
 * Servlet implementation class Sprodeletecon
 */
@WebServlet("/Sprodeletecon")
public class Sprodeletecon extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sprodeletecon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		if(email != null) {
			String pass = request.getParameter("pass");
			StudentDao sdao = new StudentDao();
			HttpSession hs = request.getSession(true);
			hs.setAttribute("Sprodeletecon", "Active");
			int i = sdao.sendspdl(email,pass);
			if(i > 0) {
				if(i == 5) {
					hs.setAttribute("spdl", "Delete Profile Link Sent To Your Mail");
					response.sendRedirect("slr.jsp");
				}
			}else {
				hs.setAttribute("invalidcred", "Oops !! Invalid Credentials !!");
				response.sendRedirect("sprodelete.jsp");
			}
		}else {
			response.sendRedirect("sdashboard.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
