package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.TeacherDao;
import com.quiz.model.Subject;

/**
 * Servlet implementation class Regsubcon
 */
@WebServlet("/Regsubcon")
public class Regsubcon extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Regsubcon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		String tid = request.getParameter("tid");
		if(tid != null) {
			String sub_id = request.getParameter("sub_id");
			String clg_id = request.getParameter("clg_id");
			String sub_name = request.getParameter("sub_name");
			String did = request.getParameter("did");
			HttpSession hs = request.getSession(true);
			hs.setAttribute("Regsubcon", "Active");
			if(tid.isEmpty() || sub_id.isEmpty() || sub_name.isEmpty() || clg_id.isEmpty()) {
				hs.setAttribute("fieldsrequired", "All fields are mandatory !!");
			}else {
				if(!Pattern.matches("[^\\s]+", sub_id)){
					System.out.println("Id Shouldn't have space");
					hs.setAttribute("idspace", "Should not have space in Subject ID");
				}else {
					if(!Pattern.matches("^[a-zA-Z0-9\\s]*$",sub_name)) {
						hs.setAttribute("alphabetsonly", "Subject Name Should Have Alphabets & Numbers Only !!");
					}else {
						TeacherDao tdao = new TeacherDao();
						int csub_id = tdao.checksub_id(sub_id,clg_id);
						if(csub_id > 0) {
							hs.setAttribute("sub_idexist", "Subject ID Already Exist !!");
						}else {
							Subject s = new Subject(tid,did,clg_id,sub_id, sub_name);
							int i = tdao.sub_register(s);
							if(i > 0) {
								LinkedList<Subject> sub_list = tdao.AlltSubjects(tid);
								LinkedList<Subject> inactivesub_list = tdao.AllinactiveSubjects(tid);

								int sub_count = 0;
								if(sub_list != null) {
									sub_count = sub_list.size();
								}
								hs.setAttribute("sub_count", sub_count);
								hs.setAttribute("sub_list", sub_list);
								hs.setAttribute("inactivesub_list", inactivesub_list);

								hs.setAttribute("sub_reg_status", "Subject Registered Successfully !!");
							}
						}
					}
				}
			}
			response.sendRedirect("tsubjects.jsp");
		}else{
			response.sendRedirect("index.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
