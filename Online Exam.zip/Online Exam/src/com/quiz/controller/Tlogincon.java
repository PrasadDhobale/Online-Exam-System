package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.Dao.TeacherDao;
import com.quiz.model.Quiz;
import com.quiz.model.Student;
import com.quiz.model.Subject;
import com.quiz.model.Teacher;

/**
 * Servlet implementation class Tlogincon
 */
@WebServlet("/Tlogincon")
public class Tlogincon extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Tlogincon() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tidemail = request.getParameter("tidemail");
		if(tidemail != null) {
			String pass = request.getParameter("pass");
			HttpSession hs = request.getSession(true);
			hs.setAttribute("Tlogincon", "Active");
			if(tidemail.isEmpty() || pass.isEmpty()) {
				hs.setAttribute("fieldsrequired", "All Fields are Mandatory !!");
				response.sendRedirect("tlr.jsp");
			}else {
				TeacherDao tdao = new TeacherDao();
				Teacher t = tdao.Login(tidemail, pass);
				if(t != null) {
					String tid = tdao.checkeverification(tidemail);				
					if(tid.equals("Active")) {
						hs.setAttribute("tprofile", t);
						LinkedList<Teacher> tlist = tdao.otherteacher(t.getClg_id(),t.getTid());
						LinkedList<Student> slist = tdao.AllStudents(t.getClg_id(),t.getDid());
						
						LinkedList<Subject> sub_list = tdao.AlltSubjects(t.getTid());
						
						LinkedList<Subject> inactivesub_list = tdao.AllinactiveSubjects(t.getTid());
						LinkedList<Subject> activesub_list = tdao.AllactiveSubjects(t.getTid());
						QuizDao qdao = new QuizDao();

						int quiz_counter = qdao.quiz_counter(t.getTid());
						//LinkedList<Quiz> quiz_list = qdao.getTQuiz(t.getTid());
						

						int scount = 0;
						int sub_count = 0;
						if(slist != null) {
							scount = slist.size();
						}
						if(sub_list!=null) {
							sub_count = sub_list.size();
						}						
						hs.setAttribute("sub_list", sub_list);
						hs.setAttribute("inactivesub_list", inactivesub_list);
						hs.setAttribute("activesub_list", activesub_list);
						hs.setAttribute("sub_count", sub_count);
						hs.setAttribute("tlist", tlist);
						hs.setAttribute("scount", scount);
						hs.setAttribute("slist", slist);
						hs.setAttribute("quiz_counter", quiz_counter);
						//hs.setAttribute("quiz_list", quiz_list);
						hs.setAttribute("tfname", t.getFname());
						response.sendRedirect("tdashboard.jsp");
					}else {
						hs.setAttribute("cev","Email Not Verified Please Verify Your Email First");
						hs.setAttribute("tid", tid);
						response.sendRedirect("tlr.jsp");
					}
				}else{
					hs.setAttribute("credentials", "Invalid Credentials !!");
					response.sendRedirect("tlr.jsp");
				}
			}
		}else {
			response.sendRedirect("tlr.jsp");
		}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
