package com.quiz.controller;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.Dao.TeacherDao;
import com.quiz.model.Subject;

/**
 * Servlet implementation class Tdel_Quiz
 */
@WebServlet("/Tdel_Quiz")
public class Tdel_Quiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Tdel_Quiz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String quiz_id = request.getParameter("quiz_id");
		if(quiz_id != null) {
			String tid = request.getParameter("tid");
			HttpSession hs = request.getSession(true);
			QuizDao qdao = new QuizDao();
			int qd = qdao.del_Quiz(tid,quiz_id);
			if(qd > 0) {
				
				TeacherDao tdao = new TeacherDao();
				LinkedList<Subject> inactivesub_list = tdao.AllinactiveSubjects(tid);
				LinkedList<Subject> activesub_list = tdao.AllactiveSubjects(tid);
				LinkedList<Subject> sub_list = tdao.AlltSubjects(tid);
				int quiz_counter = qdao.quiz_counter(tid);
				hs.setAttribute("quiz_counter", quiz_counter);
				hs.setAttribute("inactivesub_list", inactivesub_list);
				hs.setAttribute("activesub_list", activesub_list);
				hs.setAttribute("Tdel_Quizcon", "Quiz Deleted Successfully !!");
				hs.setAttribute("sub_list", sub_list);
			}
			response.sendRedirect("tschedule.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
