package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.TeacherDao;
import com.quiz.model.Student;
import com.quiz.model.Teacher;

/**
 * Servlet implementation class Delstudcon
 */
@WebServlet("/Delstudcon")
public class Delstudcon extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Delstudcon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sid = request.getParameter("sid");
		if(sid != null) {
			HttpSession hs = request.getSession(true);
			hs.setAttribute("Delstudcon", "Active");
			Teacher t = (Teacher) hs.getAttribute("tprofile");
			String delbtn = request.getParameter("delbtn");
			String sendwarn = request.getParameter("sendwarn");
			String reason = request.getParameter("reason");
			System.out.println(sid+"\t"+reason);
			
			if(sid.isEmpty() || reason.isEmpty()) {
				hs.setAttribute("emptyfields", "All fields are mandatory !!");
			}else {
				TeacherDao tdao = new TeacherDao();
				
//				System.out.println(sid+"\t"+t.getDid()+"\t"+t.getClg_id());
				int cs = tdao.check_student(sid, t.getDid(), t.getClg_id());
				if(cs > 0) {
					if(delbtn != null) {
						hs.setAttribute("deletestudent", "Active");
						
						int ds = tdao.delete_student(sid);
						if(ds > 0) {
							int sr = tdao.store_reason(t.getTid(),t.getDid(),t.getClg_id(),sid,reason);
							if(sr > 0) {
								LinkedList<Student> slist = tdao.AllStudents(t.getClg_id(),t.getDid());
								int scount = 0;
								if(slist != null) {
									scount = slist.size();
								}
								hs.setAttribute("scount", scount);
								hs.setAttribute("deletestatus", "Student Removed Successfully !!");
							}
						}
					}else if(sendwarn != null) {
						hs.setAttribute("sendwarn", "Active");
						
						int sw = tdao.sendwarn(t.getTid(),t.getEmail(),sid,reason);
						if(sw > 0) {
							int sr = tdao.store_reason(t.getTid(),t.getDid(),t.getClg_id(),sid,reason);
							if(sr > 0) {
								hs.setAttribute("swstatus", "Warnning Sent Successfully !!");
							}
						}
					}
				}else {
					hs.setAttribute("studnotexist", "Student Not Exist In Your Department !!");
				}
			}
			response.sendRedirect("tdeletestud.jsp");
		}else {
			response.sendRedirect("tdashboard.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
