package com.quiz.controller;

import java.io.IOException;
import java.util.LinkedList;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.TeacherDao;
import com.quiz.model.Student;
import com.quiz.model.Teacher;

/**
 * Servlet implementation class Tproupdatecon
 */
@WebServlet("/Tproupdatecon")
public class Tproupdatecon extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Tproupdatecon() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname = request.getParameter("fname");
		if(fname != null) {

			HttpSession hs = request.getSession(true);			
			hs.setAttribute("Tproupdatecon", "Active");
			String lname = request.getParameter("lname");			
			String did = request.getParameter("did");
			Teacher teach = (Teacher) hs.getAttribute("tprofile");
			String tid = teach.getTid();
			String clg_id = teach.getClg_id();
			String clg_name = request.getParameter("clg_name");
			String email = teach.getEmail();
			String pass = request.getParameter("pass");
			if(fname.isEmpty() || lname.isEmpty() || tid.isEmpty() || did.isEmpty() || clg_id.isEmpty() || clg_name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
				hs.setAttribute("fieldsrequired", "All Fields are Mandatory !!");
				response.sendRedirect("tproupdate.jsp");
			}else {
				if(!Pattern.matches("[^\s]+", tid) || !Pattern.matches("[^\s]+", did) || !Pattern.matches("[^\s]+", clg_id)){
					hs.setAttribute("idspace", "ID Should Not Have Space !!");
					response.sendRedirect("tproupdate.jsp");
				}else {
					if(!Pattern.matches("[A-Za-z]+", fname) || !Pattern.matches("[A-Za-z]+", lname) || !Pattern.matches("^[a-zA-Z\s]*$|[0-9]*$", clg_name)) {
						hs.setAttribute("alphabetsonly", "Firstname,Lastname and College Name must be alphabets only !!");
						response.sendRedirect("tproupdate.jsp");
					}else {
						String regex = "^(?=.*[0-9])"
								+ "(?=.*[a-z])(?=.*[A-Z])"
								+ "(?=.*[@#$%^&+=])"
								+ "(?=\\S+$).{8,20}$";
	
						if(!Pattern.matches(regex, pass)) {
							hs.setAttribute("passpattern", "Password Should Be Contain alphanumeric Character");
							response.sendRedirect("tproupdate.jsp");
						}else {
							TeacherDao tdao = new TeacherDao();
							Teacher t = new Teacher(fname, lname, tid, did, clg_id, clg_name, email, pass);
							t = tdao.tprofileupdate(t);
							if(t != null) {
								hs.setAttribute("tprofile", t);
								LinkedList<Student> slist = tdao.AllStudents(t.getClg_id(),t.getDid());
								int scount = 0;
								if(slist != null) {
									scount = slist.size();
								}
								hs.setAttribute("scount", scount);
								hs.setAttribute("slist", slist);
								hs.setAttribute("tproupdated", "Profile Updated Successfully !!");				
							}
							response.sendRedirect("tprofile.jsp");
						}
					}
				}
			}
		}else {
			response.sendRedirect("tdashboard.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}