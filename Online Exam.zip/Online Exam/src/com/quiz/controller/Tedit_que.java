package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.Dao.TeacherDao;
import com.quiz.model.Quiz;
import com.quiz.model.Subject;

/**
 * Servlet implementation class Tedit_que
 */
@WebServlet("/Tedit_que")
public class Tedit_que extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Tedit_que() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tid = request.getParameter("tid");
		if(tid != null) {
			HttpSession hs =request.getSession(true);
			String did = request.getParameter("did");
			String clg_id = request.getParameter("clg_id");
			String quiz_id = request.getParameter("quiz_id");
			String oq_name = request.getParameter("oq_name");
			String q_name = request.getParameter("nq_name");
			String op_1 = request.getParameter("o_1");
			String op_2 = request.getParameter("o_2");
			String op_3 = request.getParameter("o_3");
			String op_4 = request.getParameter("o_4");
			String ca = request.getParameter("ca");
			int q_mark = Integer.parseInt(request.getParameter("q_mark"));
			
			Quiz q = new Quiz(tid, did, clg_id, quiz_id, "Que_edit", q_name, op_1, op_2, op_3, op_4, ca, q_mark);
			QuizDao qdao = new QuizDao();
			TeacherDao tdao = new TeacherDao();
			int eq = qdao.edit_question(q,oq_name);
			LinkedList<Subject> activesub_list = tdao.AllactiveSubjects(tid);
			LinkedList<Quiz> quiz_list = qdao.getTQuiz(tid,quiz_id);
			hs.setAttribute("quiz_list", quiz_list);
			hs.setAttribute("activesub_list", activesub_list);
			response.sendRedirect("tquizdetails.jsp");
		}else {
			response.sendRedirect("tdashboard.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
