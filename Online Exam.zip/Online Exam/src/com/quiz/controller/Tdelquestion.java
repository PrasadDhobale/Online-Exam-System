package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.model.Quiz;

/**
 * Servlet implementation class Tdelquestion
 */
@WebServlet("/Tdelquestion")
public class Tdelquestion extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Tdelquestion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tid = request.getParameter("tid");
		if(tid != null) {
			HttpSession hs = request.getSession(true);
			String q_name = request.getParameter("q_name");
			String quiz_id = request.getParameter("quiz_id");
			QuizDao qdao = new QuizDao();
			int dq = qdao.delete_question(tid,quiz_id,q_name);
			LinkedList<Quiz> quiz_list = qdao.getTQuiz(tid,quiz_id);
			hs.setAttribute("quiz_list", quiz_list);
			response.sendRedirect("tquizdetails.jsp");
		}else {
			response.sendRedirect("tdashboard.jsp");
		}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
