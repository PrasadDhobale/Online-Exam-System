package com.quiz.controller;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.TeacherDao;
import com.quiz.model.Subject;

/**
 * Servlet implementation class Teditsubject
 */
@WebServlet("/Teditsubject")
public class Teditsubject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Teditsubject() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sub_id = request.getParameter("sub_id");
		if(sub_id != null) {
			String sub_name = request.getParameter("sub_name");
			String tid = request.getParameter("tid");
			HttpSession hs = request.getSession(true);
			hs.setAttribute("Teditsubject", "Active");
			TeacherDao tdao = new TeacherDao();
			int us = tdao.update_subject(sub_id,sub_name);
			if(us > 0) {
				LinkedList<Subject> sub_list = tdao.AlltSubjects(tid);
				int sub_count = 0;
				if(sub_list != null) {
					sub_count = sub_list.size();
				}
				hs.setAttribute("sub_count", sub_count);
				hs.setAttribute("sub_list", sub_list);
				hs.setAttribute("sub_updated", "Details Updated Successfully !!");
			}
		}
		response.sendRedirect("tsubjects.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
