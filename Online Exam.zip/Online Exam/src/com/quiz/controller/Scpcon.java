package com.quiz.controller;

import java.io.IOException;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.quiz.Dao.StudentDao;
import com.quiz.model.Student;

/**
 * Servlet implementation class Scpcon
 */
@WebServlet("/Scpcon")
public class Scpcon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Scpcon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String op = request.getParameter("op");
		if(op != null) {
			String np = request.getParameter("np");
			String cp = request.getParameter("cp");
			String sid = request.getParameter("sid");
			HttpSession hs = request.getSession(true);
			hs.setAttribute("Scpcon", "Active");
			
			if(op.isEmpty() || cp.isEmpty() || sid.isEmpty()) {
				hs.setAttribute("fieldsrequired", "All Fields are mandatory !!");
				response.sendRedirect("scp.jsp");
			}else {
				String regex = "^(?=.*[0-9])"
						+ "(?=.*[a-z])(?=.*[A-Z])"
						+ "(?=.*[@#$%^&+=])"
						+ "(?=\\S+$).{8,20}$";

				if(!Pattern.matches(regex, cp)) {
					hs.setAttribute("passpattern", "Password Should Be Contain alphanumeric Character");
					response.sendRedirect("scp.jsp");
				}else {
			
					if(np.equals(cp)) {
						StudentDao sdao = new StudentDao();				
						Student checkpass = sdao.Login(sid, op);
						System.out.println(checkpass);
						if(checkpass != null) {
							Student s = sdao.scp(sid, cp);
							if(s != null) {
								hs.setAttribute("sprofile", s);
								hs.setAttribute("passchanged", "Password Updated Successfully");
								response.sendRedirect("sprofile.jsp");
							}else {
								response.sendRedirect("scp.jsp");
							}
						}else {
							hs.setAttribute("opnotmatched", "Incorrect Old Password !!");
							response.sendRedirect("scp.jsp");
						}
					}else {
						hs.setAttribute("notmatch", "Password Not Matched !!");
						response.sendRedirect("scp.jsp");				
					}
				}
			}
		}else {
			response.sendRedirect("slr.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
