package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.model.Quiz;

/**
 * Servlet implementation class Squiz_Submit
 */
@WebServlet("/Squiz_Submit")
public class Squiz_Submit extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Squiz_Submit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("submit_test") != null){
			
			String sid = request.getParameter("sid");
			String did = request.getParameter("did");
			String clg_id = request.getParameter("clg_id");
			
			HttpSession hs = request.getSession(true);
			hs.setAttribute("Squiz_Submit", "Squiz_submit");
			
			int marks = 0;
			int total_mark = 0;
			String tid = null;
			String quiz_id = null;
			LinkedList<Quiz> q_list = (LinkedList)hs.getAttribute("quiz");
			LinkedList<Quiz> s_response = new LinkedList<Quiz>();
			for(Quiz quiz : q_list){
				tid = quiz.getTid();
				quiz_id = quiz.getQuiz_id();
				total_mark +=  quiz.getQ_marks();
				String sa = request.getParameter("op"+quiz.getQname());
				
				Quiz q = new Quiz(sid, quiz.getDid(), quiz.getClg_id(), quiz.getQuiz_id(), quiz.getQuiz_name(), quiz.getQname(), quiz.getOp_1(),quiz.getOp_2(), quiz.getOp_3(), quiz.getOp_4(), quiz.getCorrect_ans(), quiz.getQ_marks());
				q.setStud_ans(sa);
				s_response.add(q);
				if(sa.equals(quiz.getCorrect_ans())){
					marks += quiz.getQ_marks();
				}
			}
			QuizDao qdao = new QuizDao();
			int s_res = qdao.stud_response(s_response);
			System.out.println(s_res);
			if (s_res > 0) {
				int res = qdao.q_result(sid, tid, did, clg_id, quiz_id, total_mark, marks);
				hs.setAttribute("quiz_submit", "Quiz Submitted Successfully");
			}
			response.sendRedirect("sdashboard.jsp");
		}else {
			response.sendRedirect("sdashboard.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
