package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.Dao.TeacherDao;
import com.quiz.model.Quiz;
import com.quiz.model.Subject;

/**
 * Servlet implementation class Tedittiming
 */
@WebServlet("/Tedittiming")
public class Tedittiming extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Tedittiming() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String q_pub_time = request.getParameter("q_pub_time");
		if(q_pub_time != null) {
			HttpSession hs = request.getSession(true);
			q_pub_time = q_pub_time.replace("T", " ");
			
			String q_dur = request.getParameter("q_dur");
			String tid = request.getParameter("tid");
			String quiz_id = request.getParameter("quiz_id");
			System.out.println(tid+"\t"+quiz_id+"\t"+q_pub_time+"\t"+q_dur);
			
			QuizDao qdao = new QuizDao();
			TeacherDao tdao = new TeacherDao();
			int et = qdao.edittiming(tid,quiz_id,q_pub_time,q_dur);
			LinkedList<Subject> activesub_list = tdao.AllactiveSubjects(tid);
			LinkedList<Quiz> quiz_list = qdao.getTQuiz(tid,quiz_id);
			hs.setAttribute("activesub_list", activesub_list);
			hs.setAttribute("quiz_list", quiz_list);
			response.sendRedirect("tquizdetails.jsp");
		}else {
			response.sendRedirect("tdashboard.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
