package com.quiz.controller;

import java.io.IOException;
import java.util.LinkedList;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.StudentDao;
import com.quiz.Dao.TeacherDao;
import com.quiz.model.Student;
import com.quiz.model.Subject;

/**
 * Servlet implementation class Sproupdatecon
 */
@WebServlet("/Sproupdatecon")
public class Sproupdatecon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sproupdatecon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname = request.getParameter("fname");
		if(fname != null) {
			String lname = request.getParameter("lname");			
			String did = request.getParameter("did");
			String clg_name = request.getParameter("clg_name");			
			HttpSession hs = request.getSession(true);
			Student stud = (Student) hs.getAttribute("sprofile");
			String sid = stud.getSid();
			String clg_id = stud.getClg_id();
			String email = stud.getEmail();
			String pass = request.getParameter("pass");
						
			hs.setAttribute("Sproupdatecon", "Active");
			
			if(fname.isEmpty() || lname.isEmpty() || sid.isEmpty() || did.isEmpty() || clg_id.isEmpty() || clg_name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
				hs.setAttribute("fieldsrequired", "All Fields are Mandatory !!");
				response.sendRedirect("sproupdate.jsp");
			}else {
				if(!Pattern.matches("[^\\s]+", sid) || !Pattern.matches("[^\\s]+", did) || !Pattern.matches("[^\\s]+", clg_id)){
					hs.setAttribute("idspace", "ID Should Not Have Space !!");
				}else {
					if(!Pattern.matches("[A-Za-z]+", fname) || !Pattern.matches("[A-Za-z]+", lname) || !Pattern.matches("^[a-zA-Z0-9\\s]*$", clg_name)) {
						hs.setAttribute("alphabetsonly", "Firstname,Lastname and College Name must be alphabets and numbers only !!");
						response.sendRedirect("sproupdate.jsp");
					}else {
						String regex = "^(?=.*[0-9])"
								+ "(?=.*[a-z])(?=.*[A-Z])"
								+ "(?=.*[@#$%^&+=])"
								+ "(?=\\S+$).{8,20}$";
						if(!Pattern.matches(regex, pass)) {
							hs.setAttribute("passpattern", "Password Should Be Contain alphanumeric Character");
							response.sendRedirect("sproupdate.jsp");
						}else {
							StudentDao sdao = new StudentDao();
							Student s = new Student(fname, lname, sid, did, clg_id, clg_name, email, pass);
							s = sdao.sprofileupdate(s);
							if(s != null) {
								TeacherDao tdao = new TeacherDao();
								LinkedList<Subject> sub_list = tdao.AlldSubjects(did);
								int sub_count = 0;
								if(sub_list != null) {
									sub_count = sub_list.size();
								}
								hs.setAttribute("sub_count", sub_count);
								hs.setAttribute("sub_list", sub_list);
								hs.setAttribute("sprofile", s);
								hs.setAttribute("sproupdated", "Profile Updated Successfully !!");
							}
							response.sendRedirect("sprofile.jsp");
						}
					}
				}
			}
		}else {
			response.sendRedirect("sdashboard.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
