package com.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.quiz.Dao.StudentDao;
import com.quiz.Dao.TeacherDao;

/**
 * Servlet implementation class Ev
 */
@WebServlet("/Ev")
public class Ev extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ev() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String key = request.getParameter("id");
		if(key != null) {
			PrintWriter pw = response.getWriter();
			pw.println("<script type='text/javascript'>");
			
			String r = request.getParameter("r");
			String email = request.getParameter("email");
			if(r.equals("s")) {
				StudentDao sdao = new StudentDao();
				int sep = sdao.verifyid_email(key, email);
				if(sep > 0) {
					sdao.email_verified(key);
					pw.println("alert('!! Email Verified Successfully !!');");
					pw.println("location='slr.jsp';");
					pw.println("</script>");
				}else {
					pw.println("alert('!! Email Not Verified !!');");
					pw.println("location='slr.jsp';");
				}
			}else {
				TeacherDao tdao = new TeacherDao();
				int tep = tdao.verifyid_email(key, email);
				if(tep > 0) {
					tdao.email_verified(key);
					pw.println("alert('!! Email Verified Successfully !!');");
					pw.println("location='tlr.jsp';");
				}else {
					pw.println("alert('!! Email Not Verified !!');");
					pw.println("location='tlr.jsp';");
				}
			}
			pw.println("</script>");
		}else {
			response.sendRedirect("tlr.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
