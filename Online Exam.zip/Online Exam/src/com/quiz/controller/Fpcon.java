package com.quiz.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.TeacherDao;

/**
 * Servlet implementation class Fpcon
 */
@WebServlet("/Fpcon")
public class Fpcon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Fpcon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		if(email != null) {
			TeacherDao tdao = new TeacherDao();
			HttpSession hs = request.getSession(true);			
			
			
			hs.setAttribute("Fpcon", "Active");
			if(email.isEmpty()) {
				hs.setAttribute("emailrequired", "Email Is Required !!");
			}else {
				int e = tdao.checktid_email("abc", email);			
				if(e != 0) {				
					
					String tid = tdao.checkeverification(email);
					System.out.println(tid);
					if(tid.equals("Active")) {
						int i = tdao.sendpass(email);
						if(i != 0) {
							hs.setAttribute("passsent", "Password Sent to Your Email");
						}
					}else {
						hs.setAttribute("cev","Email Not Verified Please Verify Your Email First");
						hs.setAttribute("tid", tid);
					}
				}else {
					System.out.println("Not Exist");
					hs.setAttribute("emailexist", "Oops !! Email Not Registered With Us ");
				}
			}
		}
		response.sendRedirect("tfp.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
