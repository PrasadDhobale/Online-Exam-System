package com.quiz.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.StudentDao;

/**
 * Servlet implementation class SFpcon
 */
@WebServlet("/SFpcon")
public class SFpcon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SFpcon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		if(email != null) {
			StudentDao sdao = new StudentDao();
			HttpSession hs = request.getSession(true);			
			
			hs.setAttribute("SFpcon", "Active");
			if(email.isEmpty()) {
				hs.setAttribute("emailrequired", "Email Is Required !!");
			}else {			
				int e = sdao.checktid_email("0", email);			
				if(e != 0) {				
					
					String sid = sdao.checkeverification(email);				
					if(sid.equals("Active")) {
						int i = sdao.sendpass(email);
						if(i != 0) {
							hs.setAttribute("passsent", "Password Sent to Your Email");
						}
					}else {
						hs.setAttribute("cev","Email Not Verified Please Verify Your Email First");
						hs.setAttribute("sid", sid);
					}
				}else {
					System.out.println("Not Exist");
					hs.setAttribute("emailexist", "Oops !! Email Not Registered With Us ");
				}
			}
		}
		response.sendRedirect("sfp.jsp");
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
