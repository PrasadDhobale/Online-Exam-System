package com.quiz.controller;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.model.Quiz;

/**
 * Servlet implementation class SQuiz
 */
@WebServlet("/SQuiz")
public class SQuiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SQuiz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String did = request.getParameter("did");
		if(did != null) {
			String quiz_id = request.getParameter("sub_id");
			HttpSession hs = request.getSession(true);
			hs.setAttribute("quiz_id", quiz_id);
			QuizDao qdao = new QuizDao();
			LinkedList<Quiz> quiz_list = qdao.getDQuiz(did,quiz_id);
			
			if(quiz_list != null) {
				hs.setAttribute("quiz", quiz_list);
				hs.setAttribute("q_dur", quiz_list.get(0).getQ_dur());
			}
			response.sendRedirect("SQuiz.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
