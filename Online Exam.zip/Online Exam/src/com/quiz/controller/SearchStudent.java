package com.quiz.controller;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.TeacherDao;
import com.quiz.model.Student;

/**
 * Servlet implementation class SearchStudent
 */
@WebServlet("/SearchStudent")
public class SearchStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String search = request.getParameter("search");
		if(search != null) {
			String did = request.getParameter("did");
			System.out.println(search+"\t"+did);
			HttpSession hs = request.getSession(true);
			hs.setAttribute("SearchStudent", "Active");
			TeacherDao tdao = new TeacherDao();
			LinkedList<Student> search_list = tdao.SearchStudent(did,search);
			if(search_list != null) {
				hs.setAttribute("search_list", search_list);
			}else {
				hs.setAttribute("search_list", null);
			}
		}
		response.sendRedirect("searchstudent.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
