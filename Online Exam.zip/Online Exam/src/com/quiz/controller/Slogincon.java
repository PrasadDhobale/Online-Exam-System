package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.StudentDao;
import com.quiz.Dao.TeacherDao;
import com.quiz.model.Student;
import com.quiz.model.Subject;

/**
 * Servlet implementation class Slogincon
 */
@WebServlet("/Slogincon")
public class Slogincon extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Slogincon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sidemail = request.getParameter("sidemail");
		if(sidemail != null) {
			String pass = request.getParameter("pass");
			
			HttpSession hs = request.getSession(true);			
			hs.setAttribute("Slogincon", "Active");
			if(sidemail.isEmpty() || pass.isEmpty()) {
				hs.setAttribute("fieldsrequired", "All Fields are Mandatory !!");
				response.sendRedirect("slr.jsp");
			}else {			
				StudentDao sdao = new StudentDao();
				Student s = sdao.Login(sidemail, pass);
				if(s != null) {
					String sid = sdao.checkeverification(sidemail);				
					if(sid.equals("Active")) {
						TeacherDao tdao = new TeacherDao();

						LinkedList<Subject> sub_list = tdao.AlldSubjects(s.getDid(),s.getClg_id());
						LinkedList<Subject> q_active_sub = sdao.AllactiveSubjects(s.getDid(), s.getClg_id());
						int sub_count = 0;
						if(sub_list != null) {
							sub_count = sub_list.size();
						}
						hs.setAttribute("sub_list", sub_list);
						hs.setAttribute("q_active_sub", q_active_sub);
						hs.setAttribute("sub_count", sub_count);
						int q_counter = 0;
						if(q_active_sub != null) {
							q_counter = q_active_sub.size();
						}
						hs.setAttribute("q_active_counter", q_counter);
						hs.setAttribute("sprofile", s);
						hs.setAttribute("sfname", s.getFname());
						response.sendRedirect("sdashboard.jsp");
					}else {
						hs.setAttribute("cev","Email Not Verified Please Verify Your Email First");
						hs.setAttribute("sid", sid);
						response.sendRedirect("slr.jsp");
					}
				}else{
					hs.setAttribute("credentials", "Invalid Credentials !!");
					response.sendRedirect("slr.jsp");
				}
			}
		}else {
			response.sendRedirect("tlr.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
