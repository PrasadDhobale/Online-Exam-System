package com.quiz.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.model.Student;
import com.quiz.model.Teacher;
import com.quiz.Dao.StudentDao;
import com.quiz.Dao.TeacherDao;

/**
 * Servlet implementation class Sevl
 */
@WebServlet("/Sevl")
public class Sevl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sevl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		if(id != null) {
			String r = request.getParameter("r");			
			System.out.println("In Sevl");
			
			HttpSession hs = request.getSession(true);
			hs.setAttribute("sevlcon", "Active");
			if(r.equals("s")) {
				StudentDao sdao = new StudentDao();
				Student s = sdao.sevl(id);
				if(s != null) {
					hs.setAttribute("smstatus", "Verification Email Sent To Your Mail Successfully");
				}
				response.sendRedirect("slr.jsp");
			}else {
				TeacherDao tdao = new TeacherDao();
				Teacher t = tdao.sevl(id);
				if(t != null) {
					hs.setAttribute("smstatus", "Verification Email Sent To Your Mail Successfully");
				}
				response.sendRedirect("tlr.jsp");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
