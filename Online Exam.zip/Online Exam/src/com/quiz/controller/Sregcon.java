package com.quiz.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.quiz.Dao.StudentDao;
import com.quiz.Dao.TeacherDao;
import com.quiz.model.Student;

/**
 * Servlet implementation class Sregcon
 */
@WebServlet("/Sregcon")
public class Sregcon extends HttpServlet implements Serializable{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sregcon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname = request.getParameter("fname");
		if(fname != null) {
			String lname = request.getParameter("lname");
			String sid = request.getParameter("sid");
			String did = request.getParameter("did");
			String clg_id = request.getParameter("clg_id");
			String clg_name = request.getParameter("clg_name");
			String email = request.getParameter("email");
			String pass = request.getParameter("pass");
			
			HttpSession hs = request.getSession(true);			
			hs.setAttribute("Sregcon", "Active");

			if(fname.isEmpty() || lname.isEmpty() || sid.isEmpty() || did.isEmpty() || clg_id.isEmpty() || clg_name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
				hs.setAttribute("fieldsrequired", "All Fields are Mandatory !!");
				System.out.println("Empty Fields");
			}else {
				
				if(!Pattern.matches("[^\s]+", sid) || !Pattern.matches("[^\s]+", did) || !Pattern.matches("[^\s]+", clg_id)){
					hs.setAttribute("idspace", "ID Should Not Have Space !!");
				}else {
					if(!Pattern.matches("[A-Za-z]+", fname) || !Pattern.matches("[A-Za-z]+", lname) || Pattern.matches("^[A-Za-z0-9]*$+", clg_name)) {
						hs.setAttribute("alphabetsonly", "Firstname,Lastname and College Name must be alphabets only !!");
						System.out.println("Alphabets Only");
					}else {
						if(!Pattern.matches("[A-Za-z0-9+_.-]+@(.+)$", email)) {
							System.out.println("Invalid Email");
							hs.setAttribute("invalidemail", "Invalid Email ID !!");
						}else {
							String regex = "^(?=.*[0-9])"
				                       + "(?=.*[a-z])(?=.*[A-Z])"
				                       + "(?=.*[@#$%^&+=])"
				                       + "(?=\\S+$).{8,20}$";
				  
							if(!Pattern.matches(regex, pass)) {
								hs.setAttribute("passpattern", "Password Should Be Contain alphanumeric Character");
							}else {
								TeacherDao tdao = new TeacherDao();
								StudentDao sdao = new StudentDao();
								int ter = tdao.checktid_email(sid, email);
								int ser = sdao.checktid_email(sid, email);
								if(ter > 0 || ser > 0) {
									hs.setAttribute("sidemailexist", "Oops !! Student ID Or Email Id Already Exist");
								}else{
									Student s = new Student(fname, lname, sid, did, clg_id, clg_name, email, pass);
									int i = sdao.student_register(s);
									if(i > 0) {
										hs.setAttribute("regstatus", "Congrats !! You Are Now Registered With Us.<br>Email Verification Link Sent to To Your Email");					
									}
								}
							}
						}
					}
				}
			}
		}
		response.sendRedirect("slr.jsp");		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}