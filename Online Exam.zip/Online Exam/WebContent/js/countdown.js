function scountdown (element,countDownDate,dom) {
	
	dom = "SQuiz?"+dom;
	
	console.log(dom);
		
	var x = setInterval(function(){
	
		var now = new Date().getTime();
	    var distance = countDownDate - now;
		
	    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
	    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
	    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
	    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
		
	    document.getElementById(element).innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
	    
	    if (distance < 0) {
	      clearInterval(x);
	      document.getElementById(element).innerHTML = "<button type='button' class='btn btn-success' data-toggle='modal' data-target='#exampleModal' data-link="+dom+"><i class='fa  fa-play'></i>&nbsp;Proceed</button>";
	    }
    },1000);
}

function countdown (element,countDownDate) {
			
	var x = setInterval(function(){
	
	var now = new Date().getTime();
    var distance = countDownDate - now;
	
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
	
    document.getElementById(element).innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
    
    if (distance < 0) {
      clearInterval(x);
      document.getElementById(element).innerHTML = "<button class='btn btn-primary'><i class='fa  fa-play'></i>&nbsp;Started</button>";
    }
    },1000);
}

function timeout(){
	var hours=Math.floor(timeLeft/3600);
	var minute=Math.floor((timeLeft-(hours*3600))/60);
	var second=timeLeft%60;

    hours = hours < 10 ? '0' + hours : hours;
    minute = minute < 10 ? '0' + minute : minute;
    second = second < 10 ? '0' + second : second;
	if(timeLeft<=0) {
		document.getElementById("timer").innerHTML = "EXPIRED";
        document.getElementById("quiz").submit();
        clearTimeout(tm);
	}
	else {
		document.getElementById("timer").innerHTML=hours+":"+minute+":"+second;
	}
	timeLeft--;
	var tm= setTimeout(function(){timeout()},1000);
}