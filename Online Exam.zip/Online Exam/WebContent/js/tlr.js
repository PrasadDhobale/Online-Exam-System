function showhide() {
    var showpassl = document.getElementById("showpassl");
    var showpassr = document.getElementById("showpassr");
    var openeyel = document.getElementById("openeyel");
    var openeyer = document.getElementById("openeyer");
    var closeeyel = document.getElementById("closeeyel");
    var closeeyer = document.getElementById("closeeyer");
    if (showpassl.type === "password") {
        showpassl.type = "text";
        closeeyel.style.display = "block";
        openeyel.style.display = "none";
    } else {
        showpassl.type = "password";
        openeyel.style.display = "block";
        closeeyel.style.display = "none";
    }
    if (showpassr.type === "password") {
        showpassr.type = "text";
        closeeyer.style.display = "block";
        openeyer.style.display = "none";
    } else {
        showpassr.type = "password";
        openeyer.style.display = "block";
        closeeyer.style.display = "none";
    }
}
function hidemsg(){
	var x = document.getElementById("msg");
	x.style.display = "none";
}